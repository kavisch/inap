﻿using INAIPI.Models;
using INAIPI.Models.Request;
using INAIPI.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INAIPI.Service.Definition
{
    public interface IUserService
    {
        Task<ClientResponse<LoginResponse>> Login(LoginRequest loginRequest);
    }
}
