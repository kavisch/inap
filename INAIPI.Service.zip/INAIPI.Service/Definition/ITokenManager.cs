﻿using INAIPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INAIPI.Service.Definition
{
    public interface ITokenManager
    {
        Task<ClientResponse<string>> GenerateToken(string secret, double expirationMinutes, Dictionary<string, string> claims);
        Task<ClientResponse<Dictionary<string, string>>> ValidateToken(string token, string secret);
    }
}
