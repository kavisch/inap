﻿using INAIPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INAIPI.Service.Definition
{
    public interface IMUserTypeService
    {
        Task<ClientResponse<List<UserTypeView>>> GetByAll();
        Task<ClientResponse<UserTypeView>> GetById(int Id);
        Task<ClientResponse<UserTypeView>> Create(UserTypeView _view);
        Task<ClientResponse<UserTypeView>> Edit(UserTypeView _view);
        Task<ClientResponse<bool>> Delete(int Id);
    }
}
