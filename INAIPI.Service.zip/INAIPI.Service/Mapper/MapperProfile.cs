﻿using AutoMapper;
using INAIPI.Entities;
using INAIPI.Models;
using INAIPI.Models.Response;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace INAIPI.Service.Mapper
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            /*
            CreateMap<User, ProfileResponse>()
               .ForPath(profile => profile.FirstName, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().FirstName))
               .ForPath(profile => profile.LastName, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().LastName))
               .ForPath(profile => profile.NickName, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().NickName))
               .ForPath(profile => profile.AddressLine1, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().AddressLine1))
               .ForPath(profile => profile.AddressLine2, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().AddressLine2))
               .ForPath(profile => profile.CityOther, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().CityOther))
               .ForPath(profile => profile.ZipCode, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().ZipCode))
               .ForMember(profile => profile.StateDesc, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().State.Name))
               .ForMember(profile => profile.CityDesc, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().City.CityName))
               .ReverseMap();

            CreateMap<PlanSubscription, PlanSubscriptionView>()
               .ReverseMap();

            CreateMap<State, StateView>()
               .ReverseMap();

            CreateMap<City, CityView>()
               .ReverseMap();

            CreateMap<User, LoginResponse>()
                .ForPath(m => m.UserTypeDesc, e => e.MapFrom(i => i.UserType.Title))
               .ReverseMap();
            */

            CreateMap<User, ProfileResponse>()
              .ForPath(profile => profile.FirstName, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().FirstName))
              .ForPath(profile => profile.LastName, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().LastName))
              .ForPath(profile => profile.NickName, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().NickName))
              .ForPath(profile => profile.Gender, e => e.MapFrom(user => user.UserProfile.FirstOrDefault().Gender))
              .ReverseMap();

            CreateMap<User, LoginResponse>()
                .ForPath(m => m.UserTypeDesc, e => e.MapFrom(i => i.UserType.Title))
               .ReverseMap();

            CreateMap<MuserType, UserTypeView>()
               .ForPath(m => m.Identificador, e => e.MapFrom(i => i.Id))
               .ForPath(m => m.Titulo, e => e.MapFrom(i => i.Title))
               .ForPath(m => m.Descripcion, e => e.MapFrom(i => i.Description))
               .ForPath(m => m.Habilitado, e => e.MapFrom(i => i.Enabled))
               .ForPath(m => m.IdCreador, e => e.MapFrom(i => i.CreatedBy))
               .ForPath(m => m.Creador, e => e.MapFrom(i => i.CreatedByNavigation.DisplayName))
               .ForPath(m => m.FechaCreacion, e => e.MapFrom(i => i.CreatedDate))
               .ForPath(m => m.IdModificado, e => e.MapFrom(i => i.ModifiedBy))
               .ForPath(m => m.ModificadoPor, e => e.MapFrom(i => i.ModifiedByNavigation.DisplayName))
               .ForPath(m => m.FechaModificacion, e => e.MapFrom(i => i.ModifiedDate))
               .ReverseMap();
        }
    }
}