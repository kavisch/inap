﻿using INAIPI.Models;
using INAIPI.Repository;
using INAIPI.Service.Definition;
using INAIPI.Service.Mapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INAIPI.Service.Implementation
{
    public class MUserTypeService : IMUserTypeService
    {
        private readonly ApplicationContext db;
        private readonly ICustomMapper customMapper;
        public MUserTypeService(ApplicationContext context, ICustomMapper mapper)
        {
            db = context;
            customMapper = mapper;
        }

        public async Task<ClientResponse<UserTypeView>> Create(UserTypeView _view)
        {
            var response = new ClientResponse<UserTypeView>();

            try
            {
                var entity = customMapper.Map<UserTypeView>(_view);

                db.Add(entity);
                var result = await db.SaveChangesAsync();

                if (result <= 0)
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_CREATED, ref response);
                else
                    response.Data = customMapper.Map<UserTypeView>(entity);

            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }

        public async Task<ClientResponse<bool>> Delete(int Id)
        {
            var response = new ClientResponse<bool>();
            try
            {
                var entity = await db.MuserType.FindAsync(Id);
                if (entity == null)
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_FOUND, ref response);
                    return response;
                }

                db.MuserType.Remove(entity);
                var result = await db.SaveChangesAsync() > 0;
                if (result)
                {
                    response.Data = true;
                }
            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }

        public async Task<ClientResponse<UserTypeView>> Edit(UserTypeView _view)
        {
            var response = new ClientResponse<UserTypeView>();
            try
            {

                var entity = await db.MuserType.FindAsync(_view.Identificador);
                if (entity == null)
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_FOUND, ref response);
                    return response;
                }
                entity = customMapper.Map<Entities.MuserType>(_view);

                var rows = await db.SaveChangesAsync();
                if (rows <= 0)
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_CREATED, ref response);
                    return response;
                }

                response.Data = customMapper.Map<UserTypeView>(entity);
            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }

        public async Task<ClientResponse<UserTypeView>> GetById(int Id)
        {
            var response = new ClientResponse<UserTypeView>();
            var entity = await db.MuserType
                                .AsNoTracking()
                                .Include(n => n.CreatedByNavigation)
                                .Include(n => n.ModifiedByNavigation)
                                .FirstOrDefaultAsync(f => f.Id == Id);

            response.Data = customMapper.Map<UserTypeView>(entity);
            return response;
        }

        public async Task<ClientResponse<List<UserTypeView>>> GetByAll()
        {
            var response = new ClientResponse<List<UserTypeView>>();
            var entity = await db.MuserType
                                .AsNoTracking()
                                .Include(n=> n.CreatedByNavigation)
                                .Include(n => n.ModifiedByNavigation)
                                .ToListAsync();

            response.Data = customMapper.Map<List<UserTypeView>>(entity);
            return response;
        }
    }
}
