﻿using INAIPI.Entities;
using INAIPI.Models;
using INAIPI.Models.Request;
using INAIPI.Models.Response;
using INAIPI.Repository;
using INAIPI.Service.Definition;
using INAIPI.Service.Mapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace INAIPI.Service.Implementation
{
    public class UserService : IUserService
    {
        private readonly ApplicationContext db;
        private readonly ICustomMapper customMapper;
        private readonly IConfiguration _configuration;
        private readonly ITokenManager _tokenManager;
        private readonly string _secretSaltResetToken;
        private readonly string _secretSaltRegisterToken;
        private readonly string _userCreatedDateFormat = "yyyyMMddhhmmss.fff";
        private readonly double _tokenExpirationMinutes = 1440;
        public string ProfileClaimKey => "profile";
        public UserService(ApplicationContext context, ICustomMapper mapper, IConfiguration configuration, ITokenManager tokenManager)
        {
            db = context;
            customMapper = mapper;
            _configuration = configuration;
            _tokenManager = tokenManager;
        }

        public async Task<ClientResponse<LoginResponse>> Login(LoginRequest loginRequest)
        {
            var loginResult = true;
            var response = new ClientResponse<LoginResponse>();
            try
            {
                if (string.IsNullOrEmpty(loginRequest.Email) || string.IsNullOrEmpty(loginRequest.Password))
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_AUTH_INVALID_USERNAME_LOGIN, ref response);
                    return response;
                }

                var user = await db.User
                                        .Include(u => u.UserProfile)
                                        .Include(u => u.UserType)
                                        .FirstOrDefaultAsync(w => w.Email.ToLower().Trim().Equals(loginRequest.Email.ToLower().Trim()));

                if (user == null)
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_AUTH_INVALID_USERNAME_LOGIN, ref response);
                    return response;
                }

                var result = INAIPI.Helpers.Utils.VerifyPasswordHash(loginRequest.Password, user.PasswordHash, user.PasswordSalt);
                if (!result)
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_AUTH_INVALID_USERNAME_LOGIN, ref response);
                    return response;
                }

                if (response.Code.Equals(0))
                {
                    response.Data = customMapper.Map<LoginResponse>(user);

                    user.LastAccessDate = DateTime.Now;
                    if (!string.IsNullOrEmpty(loginRequest.LastIpAddress))
                    {
                        user.LastIpAddress = loginRequest.LastIpAddress;
                    }
                    db.Update(user).State = EntityState.Modified;
                    db.Update(user).Property(x => x.Seq).IsModified = false;

                    await db.SaveChangesAsync();

                    var secretKey = _configuration.GetSection("TokenSettings")["SecretKey"];
                    double expirationInMinutes = Convert.ToDouble(_configuration.GetSection("TokenSettings")["ExpireInMinute"]);
                    Dictionary<string, string> loginClaims = new Dictionary<string, string>
                    {
                        { ClaimTypes.NameIdentifier, user.Id.ToString() },
                        { ClaimTypes.Name, user.DisplayName },
                        { ClaimTypes.Email, user.Email },
                        { ProfileClaimKey, JsonSerializer.Serialize(customMapper.Map<ProfileResponse>(user)) }
                    };

                    var tokenResponse = await _tokenManager.GenerateToken(secretKey, expirationInMinutes, loginClaims);

                    if (tokenResponse.IsSuccess)
                        response.Data.Token = tokenResponse.Data;
                    else
                        response.CopyResponse(tokenResponse);
                }

            }
            catch (SqlException sqlEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, "Problem for accesing to SQL Database.");
                loginResult = false;
                response.Data = null;
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, "System Exception");
                loginResult = false;
                response.Data = null;
            }

            return response;
        }
    }
}
