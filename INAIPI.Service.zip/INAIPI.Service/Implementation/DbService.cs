﻿using INAIPI.Models;
using INAIPI.Repository.Definition;
using INAIPI.Service.Definition;
using INAIPI.Service.Mapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INAIPI.Service.Implementation
{
    public class DbService<TEntity, TView, TId> : IDbService<TView, TId>
     where TEntity : class
     where TView : BaseView<TId>
    {

        public readonly IRepository<TEntity> Repository;
        protected readonly ICustomMapper CustomMapper;
        public DbService(IRepository<TEntity> repo, ICustomMapper mapper)
        {
            Repository = repo;
            CustomMapper = mapper;
        }

        public async Task<ClientResponse<TView>> Create(TView view)
        {
            var response = new ClientResponse<TView>();

            try
            {
                var entity = CustomMapper.Map<TEntity>(view);
                Repository.Add(entity);
                var result = await Repository.SaveChangesAsync();

                if (result <= 0)
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_CREATED, ref response);
                else
                    response.Data = CustomMapper.Map<TView>(entity);

            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }

        public async Task<ClientResponse<TView>> Edit(TView view)
        {
            var response = new ClientResponse<TView>();

            try
            {
                var entity = Repository.GetById(view.Id);
                if (entity == null)
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_FOUND, ref response);
                else
                {
                    Repository.Update(CustomMapper.Map<TEntity>(view));
                    var result = await Repository.SaveChangesAsync();

                    if (result <= 0)
                        CommonMessage.SetMessage(CommonMessage.ERROR_PASS_NOT_UPDATED, ref response);
                    else
                        response.Data = CustomMapper.Map<TView>(entity);
                }

            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }

        public async Task<ClientResponse<bool>> Delete(TId Id)
        {
            var response = new ClientResponse<bool>();

            try
            {
                var entity = Repository.GetById(Id);

                if (entity != null)
                {
                    Repository.Remove(entity);

                    var result = await Repository.SaveChangesAsync();

                    if (result <= 0)
                        CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_REMOVED, ref response);
                    else
                        response.Data = true;
                }
                else
                {
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_FOUND, ref response);
                }

            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }


        public async Task<ClientResponse<IEnumerable<TView>>> GetAll()
        {
            var response = new ClientResponse<IEnumerable<TView>>();

            try
            {
                var entities = Repository.GetAll();

                if (entities == null || entities.Count() == 0)
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_FOUND, ref response);
                else
                    response.Data = CustomMapper.Map<IEnumerable<TView>>(entities);

            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }

        public async Task<ClientResponse<TView>> GetById(TId Id)
        {
            var response = new ClientResponse<TView>();

            try
            {
                var entity = Repository.GetById(Id);

                if (entity == null)
                    CommonMessage.SetMessage(CommonMessage.ERROR_RECORD_NOT_FOUND, ref response);
                else
                    response.Data = CustomMapper.Map<TView>(entity);

            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, dbEx.Message);
            }
            catch (Exception ex)
            {
                CommonMessage.SetMessage(CommonMessage.ERROR_EXCEPTION, ref response, ex.Message);
            }

            return response;
        }
    }
}
